
# 📊 Análise de Vendas com Power BI

Este projeto demonstra um processo completo de **Análise de Dados**, desde a modelagem até a visualização,
utilizando **Power BI, SQL e conceitos de Business Intelligence**.

## 🚀 Objetivo
Analisar o desempenho de vendas, identificar indicadores (KPIs) e apoiar a tomada de decisão.

## 🛠️ Ferramentas Utilizadas
- Power BI
- SQL
- Excel / Power Query

## 📌 KPIs Analisados
- Total de Vendas
- Ticket Médio
- Quantidade de Pedidos
- Vendas por Categoria
- Vendas por Região

## 📂 Estrutura do Projeto
- `sql/` → consultas SQL utilizadas
- `dataset/` → descrição do conjunto de dados
- `dashboard/` → layout e prints do dashboard

## 👤 Autor
Marco Antônio De Souza Pereira  
Analista de Dados | Power BI | SQL | Excel
