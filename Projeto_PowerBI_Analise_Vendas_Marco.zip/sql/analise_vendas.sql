
-- Análise de Vendas por Categoria
SELECT 
    categoria,
    SUM(valor_venda) AS total_vendas
FROM vendas
GROUP BY categoria
ORDER BY total_vendas DESC;

-- Ticket Médio
SELECT 
    AVG(valor_venda) AS ticket_medio
FROM vendas;
